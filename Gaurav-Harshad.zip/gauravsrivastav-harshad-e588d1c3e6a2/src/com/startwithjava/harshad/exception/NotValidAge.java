package com.startwithjava.harshad.exception;

public class NotValidAge extends Exception{
	public NotValidAge(String s) {
		super(s);
	}
	
}
