package com.statwithjava;

public class OOPs {

	public static void test() {
		System.out.println("1111111111");
	}
	public static void test(String s) {
		System.out.println("aaa");
	}
	public static void main(String[] args) {
		test("1111");
		test();
	}

}
