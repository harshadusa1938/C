package com.startwithjava.harshad;

import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		String s[] = new String[5];
		Scanner sc = new Scanner(System.in);
		
		for(int i=0;i<5;i++){
			System.out.println("Enter string");
			s[i] = sc.nextLine();
		}
		
		for(String value:s) {
			System.out.println("Value ="+value);
		}
	}

}
