package com.statwithjava;

class AB{
	public AB(int m){
     		
	} 
}
class P extends AB{
	public P() {
		super(2);
	}
}
public class ConstructorTest {

	public static void main(String[] args) {
		

	}

}
